
export class UserDetails {
   id:string;
    Book_Title:string;
     Book_Author:string;
    Book_Count:string;
 
    constructor(id,Book_Title,Book_Author,Book_Count){
        this.id=id;
        this.Book_Title=Book_Title;
        this.Book_Author=Book_Author;
        this.Book_Count=Book_Count;
    }
}


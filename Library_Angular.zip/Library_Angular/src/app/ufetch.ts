export class Ufetch {
    id:string;
    Book_Title:string;
     Book_Author:string;
    Book_Count:string;

}

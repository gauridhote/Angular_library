export enum Role {
    User = 'User',
    Librarian = 'Librarian'
}